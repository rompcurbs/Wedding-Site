
// Types for the wedding application data structures.
export interface TimelineItem {
  time: string;
  event: string;
  description: string;
}

export interface RegistryStore {
  name: string;
  link: string;
}
