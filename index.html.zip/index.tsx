
import React, { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';

// Rendering the main App component into the root DOM element.
const rootElement = document.getElementById('root');
if (rootElement) {
  const root = createRoot(rootElement);
  root.render(
    <StrictMode>
      <App />
    </StrictMode>
  );
}
