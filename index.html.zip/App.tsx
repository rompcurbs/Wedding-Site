
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Timeline from './components/Timeline';
import DressCode from './components/DressCode';
import PhotoGallery from './components/PhotoGallery';
import HoneymoonFund from './components/HoneymoonFund';
import Registry from './components/Registry';
import Location from './components/Location';
import Footer from './components/Footer';

// The main application component assembling the wedding landing page.
const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-white selection:bg-black selection:text-white">
      <Navbar />
      <Hero />
      <Timeline />
      <DressCode />
      <PhotoGallery />
      <HoneymoonFund />
      <Registry />
      <Location />
      <Footer />
    </div>
  );
};

export default App;
