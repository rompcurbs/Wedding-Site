
// Exporting constants to fix the "not a module" error and provide data for components.
export const WEDDING_DATE = "June 08, 2026";
export const COUPLE_NAMES = "Sydney & Nicholas";
export const VENUE_ADDRESS = "1283 E Mike Weir Dr, Draper, UT 84020";

export const TIMELINE = [
  {
    time: "4:30 PM",
    event: "The Ceremony",
    description: "An intimate exchange of vows at the residence peak."
  },
  {
    time: "5:15 PM",
    event: "Cocktail Hour",
    description: "Signature drinks and hor d'oeuvres served on the terrace."
  },
  {
    time: "6:30 PM",
    event: "Dinner",
    description: "A formal black-tie dining experience under the stars."
  },
  {
    time: "8:00 PM",
    event: "Dancing",
    description: "Celebrating our union with music and company."
  },
  {
    time: "10:30 PM",
    event: "Send Off",
    description: "A final farewell to the newlyweds."
  }
];

export const DRESS_CODE_INSPIRATION = [
  "https://images.unsplash.com/photo-1594932224828-b4b059b6f6f9?q=80&w=800&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?q=80&w=800&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?q=80&w=800&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1485231183945-3bc8c3e8787c?q=80&w=800&auto=format&fit=crop"
];

export const GALLERY_PHOTOS = [
  "https://picsum.photos/800/1200?grayscale&random=1",
  "https://picsum.photos/800/800?grayscale&random=2",
  "https://picsum.photos/800/1000?grayscale&random=3",
  "https://picsum.photos/800/1100?grayscale&random=4",
  "https://picsum.photos/800/900?grayscale&random=5",
  "https://picsum.photos/800/1300?grayscale&random=6"
];

export const REGISTRY = [
  { name: "Williams Sonoma", link: "https://www.williams-sonoma.com" },
  { name: "Crate & Barrel", link: "https://www.crateandbarrel.com" },
  { name: "Restoration Hardware", link: "https://rh.com" },
  { name: "Bloomingdale's", link: "https://www.bloomingdales.com" }
];
