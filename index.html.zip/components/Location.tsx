
import React from 'react';
import { VENUE_ADDRESS } from '../constants';

const Location: React.FC = () => {
  return (
    <section id="location" className="py-24 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className="order-2 md:order-1">
            <div className="bg-gray-100 aspect-square rounded-sm flex items-center justify-center relative overflow-hidden group">
              <span className="text-gray-400 uppercase tracking-[0.3em] text-[10px] z-10">Google Map Integration</span>
              {/* Actual Map Embed */}
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3036.069416550974!2d-111.85426982343944!3d40.52352597142277!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87528766e9565555%3A0xc3f58a933f38d39e!2s1283%20E%20Mike%20Weir%20Dr%2C%20Draper%2C%20UT%2084020!5e0!3m2!1sen!2sus!4v1714500000000!5m2!1sen!2sus" 
                className="absolute inset-0 w-full h-full border-0 grayscale opacity-80 group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-1000" 
                loading="lazy"
                title="Venue Map"
              ></iframe>
            </div>
          </div>
          <div className="order-1 md:order-2 space-y-8">
            <p className="uppercase tracking-[0.3em] text-[10px] text-gray-400 font-semibold">
              The Venue
            </p>
            <h2 className="text-4xl md:text-5xl font-light italic leading-tight">
              Draper, Utah
            </h2>
            <div className="w-16 h-px bg-black/10" />
            <p className="text-gray-500 font-light leading-loose text-lg">
              Our celebration will be held at a private residence nestled in the heights of Draper.
              The location offers panoramic views of the Salt Lake Valley and provides the perfect backdrop for our evening.
            </p>
            <div className="pt-4">
              <p className="text-black text-xl font-light tracking-wide italic mb-2">The Address</p>
              <p className="text-gray-400 font-medium tracking-widest text-sm uppercase">
                {VENUE_ADDRESS}
              </p>
            </div>
            <a 
              href="https://maps.google.com" 
              className="inline-block px-8 py-4 bg-black text-white text-[10px] uppercase tracking-[0.3em] rounded-sm hover:bg-gray-800 transition-colors shadow-xl shadow-black/10"
            >
              Get Directions
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Location;
