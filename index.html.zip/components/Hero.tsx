
import React from 'react';
import { WEDDING_DATE, COUPLE_NAMES } from '../constants';

const Hero: React.FC = () => {
  return (
    <section className="relative h-screen flex flex-col items-center justify-center overflow-hidden bg-black text-white">
      {/* Background Image Placeholder */}
      <div 
        className="absolute inset-0 opacity-40 bg-center bg-cover scale-105 animate-[slow-zoom_20s_infinite_alternate]"
        style={{ backgroundImage: 'url(https://picsum.photos/1920/1080?grayscale&random=hero)' }}
      />
      
      <div className="relative z-10 text-center px-4">
        <p className="uppercase tracking-[0.4em] text-xs mb-8 opacity-80 font-light">
          Save the Date
        </p>
        <h1 className="text-6xl md:text-9xl mb-6 font-light italic leading-tight">
          {COUPLE_NAMES}
        </h1>
        <div className="h-px w-24 bg-white/40 mx-auto my-8" />
        <p className="text-lg md:text-2xl font-light tracking-[0.2em] uppercase">
          {WEDDING_DATE}
        </p>
        <p className="mt-4 text-sm tracking-[0.1em] opacity-60">
          Draper, Utah
        </p>
      </div>

      <a href="#schedule" className="absolute bottom-12 left-1/2 -translate-x-1/2 animate-bounce opacity-40 hover:opacity-100 transition-opacity">
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </a>
    </section>
  );
};

export default Hero;
