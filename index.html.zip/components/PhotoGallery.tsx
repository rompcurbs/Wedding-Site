
import React from 'react';
import { GALLERY_PHOTOS } from '../constants';

const PhotoGallery: React.FC = () => {
  return (
    <section id="gallery" className="py-24 bg-[#fafafa]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl mb-4 font-light uppercase tracking-widest italic">
            Gallery
          </h2>
          <p className="text-gray-400 uppercase tracking-widest text-[10px]">Sydney & Nicholas &bull; Engagement Series</p>
        </div>
        
        <div className="masonry-grid">
          {GALLERY_PHOTOS.map((url, idx) => (
            <div key={idx} className="masonry-item group relative overflow-hidden bg-gray-200">
              <img 
                src={url} 
                alt={`Wedding Photo ${idx}`} 
                className="w-full h-auto object-cover grayscale transition-all duration-1000 group-hover:grayscale-0 group-hover:scale-105"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PhotoGallery;
