
import React from 'react';
import { DRESS_CODE_INSPIRATION } from '../constants';

const DressCode: React.FC = () => {
  return (
    <section id="dress-code" className="py-24 bg-black text-white overflow-hidden">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <p className="uppercase tracking-[0.3em] text-[10px] text-gray-400 font-semibold">
              The Aesthetic
            </p>
            <h2 className="text-5xl md:text-6xl font-light italic leading-tight">
              Old Money — <br/> All Black
            </h2>
            <div className="w-16 h-px bg-white/20" />
            <p className="text-gray-400 font-light leading-loose text-lg max-w-md">
              We invite our guests to join us in an evening of timeless elegance. 
              Our dress code is strictly Black Tie, adhering to the classic "Old Money" aesthetic. 
              We kindly ask that all guests wear <span className="text-white font-medium">all-black attire</span> featuring elegant silhouettes and classic styling.
            </p>
            <div className="pt-4 flex items-center space-x-4">
              <span className="h-2 w-2 bg-white rounded-full"></span>
              <p className="text-sm tracking-widest uppercase opacity-60">Classic Silhouettes</p>
              <span className="h-2 w-2 bg-white rounded-full"></span>
              <p className="text-sm tracking-widest uppercase opacity-60">Timeless Details</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {DRESS_CODE_INSPIRATION.map((url, i) => (
              <div 
                key={i} 
                className={`overflow-hidden grayscale hover:grayscale-0 transition-all duration-700 cursor-pointer rounded-sm ${i % 2 === 1 ? 'mt-8' : ''}`}
              >
                <img 
                  src={url} 
                  alt={`Inspiration ${i}`} 
                  className="w-full h-full object-cover aspect-[3/4] hover:scale-105 transition-transform duration-1000"
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default DressCode;
