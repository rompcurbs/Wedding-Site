
import React from 'react';
import { TIMELINE } from '../constants';

const Timeline: React.FC = () => {
  return (
    <section id="schedule" className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <h2 className="text-4xl md:text-5xl mb-16 font-light uppercase tracking-widest">
          The Timeline
        </h2>
        
        <div className="relative border-l border-gray-100 ml-4 md:ml-auto md:mr-auto md:border-l-0">
          {TIMELINE.map((item, index) => (
            <div key={index} className="mb-12 relative flex items-center md:justify-center">
              {/* Vertical line for center alignment on desktop */}
              <div className="hidden md:block absolute w-px h-full bg-gray-100 left-1/2 -translate-x-1/2 top-10" />
              
              <div className={`flex flex-col md:flex-row items-center w-full ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}>
                <div className="flex-1 text-left md:text-right px-8 md:px-12">
                  <span className="text-sm font-medium tracking-tighter text-gray-400 mb-1 block uppercase">
                    {item.time}
                  </span>
                  <h3 className="text-2xl font-light italic mb-2">{item.event}</h3>
                  <p className="text-gray-500 text-sm font-light leading-relaxed">
                    {item.description}
                  </p>
                </div>
                
                {/* Dot */}
                <div className="absolute left-[-5px] md:static md:mx-0 w-[10px] h-[10px] bg-black rounded-full z-10" />
                
                <div className="flex-1 hidden md:block" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Timeline;
