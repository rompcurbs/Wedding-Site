
import React from 'react';
import { REGISTRY } from '../constants';

const Registry: React.FC = () => {
  return (
    <section id="registry" className="py-24 bg-black text-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl mb-4 font-light uppercase tracking-widest">
            The Registry
          </h2>
          <div className="w-16 h-px bg-white/20 mx-auto mt-6" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {REGISTRY.map((store) => (
            <div 
              key={store.name} 
              className="group bg-white/5 border border-white/10 p-10 flex flex-col items-center justify-between text-center transition-all duration-500 hover:bg-white/10 hover:border-white/20"
            >
              <div>
                <h3 className="text-xl font-light italic tracking-wider mb-6">{store.name}</h3>
                <p className="text-[10px] text-gray-400 uppercase tracking-[0.3em] font-light">
                  Home Essentials
                </p>
              </div>
              <a 
                href={store.link} 
                target="_blank" 
                rel="noopener noreferrer"
                className="mt-8 px-6 py-3 border border-white/20 text-[10px] uppercase tracking-[0.2em] hover:bg-white hover:text-black transition-all duration-300"
              >
                View Registry
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Registry;
