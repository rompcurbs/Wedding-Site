
import React from 'react';

const HoneymoonFund: React.FC = () => {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <div className="inline-block px-4 py-2 border border-gray-100 text-[10px] uppercase tracking-[0.3em] text-gray-400 mb-8">
          Gift From The Heart
        </div>
        <h2 className="text-4xl md:text-5xl mb-8 font-light italic">
          Honeymoon Fund
        </h2>
        <p className="text-gray-500 font-light leading-relaxed text-lg max-w-2xl mx-auto mb-12">
          Your presence at our wedding is the greatest gift of all. However, if you wish to honor us with a gift, a contribution towards our honeymoon adventures would be truly cherished.
        </p>
        
        <div className="bg-[#fcfcfc] border border-gray-100 p-12 max-w-sm mx-auto rounded-sm flex flex-col items-center">
          <div className="w-48 h-48 bg-gray-100 mb-8 relative border border-dashed border-gray-300 flex items-center justify-center">
             <span className="text-gray-400 uppercase tracking-widest text-[10px]">Venmo QR Code</span>
             {/* Actual img tag for QR when ready */}
             {/* <img src="venmo-qr.png" alt="Venmo QR" className="absolute inset-0 w-full h-full object-contain" /> */}
          </div>
          <p className="text-sm tracking-[0.2em] font-medium text-gray-800">@nicksaeva</p>
          <div className="h-px w-12 bg-gray-200 my-4" />
          <p className="text-xs text-gray-400 uppercase tracking-widest font-light">Venmo Username</p>
        </div>
      </div>
    </section>
  );
};

export default HoneymoonFund;
