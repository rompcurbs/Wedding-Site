
import React, { useState, useEffect } from 'react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Schedule', href: '#schedule' },
    { name: 'Dress Code', href: '#dress-code' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Registry', href: '#registry' },
    { name: 'Location', href: '#location' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 py-6 px-8 flex justify-between items-center ${isScrolled ? 'bg-white/90 backdrop-blur-md shadow-sm' : 'bg-transparent'}`}>
      <div className="serif text-xl font-semibold tracking-widest uppercase">
        S & N
      </div>
      <div className="hidden md:flex space-x-8 uppercase text-[10px] tracking-[0.2em] font-medium">
        {navLinks.map((link) => (
          <a key={link.name} href={link.href} className="hover:text-gray-400 transition-colors">
            {link.name}
          </a>
        ))}
      </div>
      <div className="md:hidden">
        {/* Simple mobile menu indicator or button can go here */}
      </div>
    </nav>
  );
};

export default Navbar;
